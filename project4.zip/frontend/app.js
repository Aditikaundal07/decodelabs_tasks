
const API='http://localhost:5000/api/interns';

async function loadInterns(){
 try{
  document.getElementById('loading').style.display='block';
  const response=await fetch(API);
  if(!response.ok) throw new Error('HTTP Error');
  const data=await response.json();

  const list=document.getElementById('list');
  list.innerHTML='';

  data.forEach(item=>{
   const li=document.createElement('li');
   li.textContent=`${item.name} - ${item.role} `;

   const edit=document.createElement('button');
   edit.textContent='Edit';
   edit.onclick=async()=>{
     const role=prompt('New Role',item.role);
     if(!role) return;
     await fetch(`${API}/${item.id}`,{
       method:'PUT',
       headers:{'Content-Type':'application/json'},
       body:JSON.stringify({role})
     });
     loadInterns();
   };

   const del=document.createElement('button');
   del.textContent='Delete';
   del.onclick=async()=>{
     await fetch(`${API}/${item.id}`,{method:'DELETE'});
     loadInterns();
   };

   li.append(edit,del);
   list.appendChild(li);
  });
 }catch(err){
  document.getElementById('msg').textContent='Error: '+err.message;
 }finally{
  document.getElementById('loading').style.display='none';
 }
}

document.getElementById('form').addEventListener('submit',async(e)=>{
 e.preventDefault();
 try{
  await fetch(API,{
   method:'POST',
   headers:{'Content-Type':'application/json'},
   body:JSON.stringify({
    name:name.value,
    role:role.value
   })
  });
  e.target.reset();
  loadInterns();
 }catch(err){
  console.error(err);
 }
});

loadInterns();
