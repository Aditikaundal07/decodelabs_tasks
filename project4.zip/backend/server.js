
const express=require('express');
const cors=require('cors');
const app=express();

app.use(cors());
app.use(express.json());

let interns=[
{id:1,name:'Aman',role:'Frontend'},
{id:2,name:'Sara',role:'Backend'}
];

app.get('/api/interns',(req,res)=>res.status(200).json(interns));

app.post('/api/interns',(req,res)=>{
 const {name,role}=req.body;
 if(!name||!role) return res.status(400).json({message:'Name and role required'});
 const intern={id:Date.now(),name,role};
 interns.push(intern);
 res.status(201).json(intern);
});

app.put('/api/interns/:id',(req,res)=>{
 const id=Number(req.params.id);
 const i=interns.findIndex(x=>x.id===id);
 if(i===-1) return res.status(404).json({message:'Not found'});
 interns[i]={...interns[i],...req.body};
 res.status(200).json(interns[i]);
});

app.delete('/api/interns/:id',(req,res)=>{
 const id=Number(req.params.id);
 interns=interns.filter(x=>x.id!==id);
 res.status(200).json({message:'Deleted'});
});

app.listen(5000,()=>console.log('API running on http://localhost:5000'));
