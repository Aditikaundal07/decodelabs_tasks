
# Intern Management System - Project 4

Concepts Covered:
- REST API (GET, POST, PUT, DELETE)
- Fetch API
- Async/Await
- JSON Parsing
- CORS
- HTTP Status Codes
- Try/Catch Error Handling
- DOM Manipulation
- IPO Architecture

Run Backend:
cd backend
npm install
npm start

Run Frontend:
Open frontend/index.html in browser.

Backend URL:
http://localhost:5000/api/interns
