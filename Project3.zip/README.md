# Project 3 Database Integration
Run: npm install && node server.js