const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const app = express();
app.use(express.json());

const db = new sqlite3.Database("./database.db");

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS courses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    course_name TEXT NOT NULL UNIQUE
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS enrollments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER,
    course_id INTEGER,
    FOREIGN KEY(student_id) REFERENCES students(id),
    FOREIGN KEY(course_id) REFERENCES courses(id)
  )`);
});

app.post("/students",(req,res)=>{
 const {name,email}=req.body;
 db.run("INSERT INTO students(name,email) VALUES (?,?)",[name,email],function(err){
   if(err) return res.status(400).json({error:err.message});
   res.status(201).json({studentId:this.lastID});
 });
});

app.get("/students",(req,res)=>{
 db.all("SELECT * FROM students",[],(err,rows)=>{
   if(err) return res.status(500).json({error:err.message});
   res.json(rows);
 });
});

app.post("/courses",(req,res)=>{
 const {course_name}=req.body;
 db.run("INSERT INTO courses(course_name) VALUES(?)",[course_name],function(err){
   if(err) return res.status(400).json({error:err.message});
   res.status(201).json({courseId:this.lastID});
 });
});

app.get("/courses",(req,res)=>{
 db.all("SELECT * FROM courses",[],(err,rows)=>{
   if(err) return res.status(500).json({error:err.message});
   res.json(rows);
 });
});

app.post("/enrollments",(req,res)=>{
 const {student_id,course_id}=req.body;
 db.run("INSERT INTO enrollments(student_id,course_id) VALUES (?,?)",[student_id,course_id],function(err){
   if(err) return res.status(400).json({error:err.message});
   res.status(201).json({message:"Enrollment Successful"});
 });
});

app.get("/enrollments",(req,res)=>{
 const sql=`SELECT enrollments.id, students.name, students.email, courses.course_name
 FROM enrollments
 JOIN students ON students.id=enrollments.student_id
 JOIN courses ON courses.id=enrollments.course_id`;
 db.all(sql,[],(err,rows)=>{
   if(err) return res.status(500).json({error:err.message});
   res.json(rows);
 });
});

app.listen(3000,()=>console.log("Server running on http://localhost:3000"));
