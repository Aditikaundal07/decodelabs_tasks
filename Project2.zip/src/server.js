
const express=require('express');
const cors=require('cors');
const app=express();

app.use(cors());
app.use(express.json());

let users=[
 {id:1,name:'Aman',email:'aman@example.com'},
 {id:2,name:'Sara',email:'sara@example.com'}
];

const validate=(req,res,next)=>{
 const {name,email}=req.body;
 if(req.method==='POST' || req.method==='PUT'){
   if(!name || !email){
      return res.status(400).json({success:false,message:'name and email required'});
   }
 }
 next();
};

app.get('/users',(req,res)=>{
 res.status(200).json({success:true,data:users});
});

app.get('/users/:id',(req,res)=>{
 const user=users.find(u=>u.id===Number(req.params.id));
 if(!user) return res.status(404).json({success:false,message:'User not found'});
 res.status(200).json(user);
});

app.post('/users',validate,(req,res)=>{
 const user={id:Date.now(),...req.body};
 users.push(user);
 res.status(201).json({success:true,data:user});
});

app.put('/users/:id',validate,(req,res)=>{
 const index=users.findIndex(u=>u.id===Number(req.params.id));
 if(index===-1) return res.status(404).json({success:false,message:'User not found'});
 users[index]={id:Number(req.params.id),...req.body};
 res.status(200).json({success:true,data:users[index]});
});

app.delete('/users/:id',(req,res)=>{
 const index=users.findIndex(u=>u.id===Number(req.params.id));
 if(index===-1) return res.status(404).json({success:false,message:'User not found'});
 users.splice(index,1);
 res.status(204).send();
});

app.use((err,req,res,next)=>{
 res.status(500).json({success:false,message:'Internal Server Error'});
});

app.listen(5000,()=>console.log('Server running on port 5000'));
