
GET    /users
GET    /users/1
POST   /users
PUT    /users/1
DELETE /users/1

POST/PUT JSON:
{
 "name":"John",
 "email":"john@example.com"
}
