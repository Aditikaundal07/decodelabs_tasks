
# DecodeLabs Project 2 - Backend API Development

Concepts Covered
- IPO Architecture
- REST API
- GET POST PUT DELETE
- RESTful Naming
- Validation (Never Trust Client)
- JSON Responses
- HTTP Status Codes (200,201,204,400,404,500)
- Error Handling
- CORS
- Stateless API Design
- Documentation

Run:

npm install
npm start

Base URL:
http://localhost:5000

Endpoints:
GET /users
GET /users/:id
POST /users
PUT /users/:id
DELETE /users/:id
